console.log('working');
var firstName = prompt('Enter your name...');
var tags = '';
var sum = 0;
var input;
// if (firstName) {
//   for (let i = 1; i <= 6; i++) {
//     tags += `<h${i}>${firstName}</h${i}>`;
//   }
// }
// if (firstName) {
//   for (var i = 1; i <= 6; i++) {
//     switch (i) {
//       case 1:
//         tags += '<h1>' + firstName + '</h1>';
//         break;
//       case 2:
//         tags += '<h2>' + firstName + '</h2>';
//         break;
//       case 3:
//         tags += '<h3>' + firstName + '</h3>';
//         break;
//       case 4:
//         tags += '<h4>' + firstName + '</h4>';
//         break;
//       case 5:
//         tags += '<h5>' + firstName + '</h5>';
//         break;
//       case 5:
//         tags += '<h5>' + firstName + '</h5>';
//         break;
//       case 6:
//         tags += '<h6>' + firstName + '</h6>';
//         break;
//     }
//   }
// }
if (firstName) {
  for (var i = 1; i <= 6; i++) {
    tags += '<h' + i + '>' + firstName + '</' + i + '>';
  }
}
document.write(tags);

do {
  input = parseInt(prompt('Enter a number...'));
  if (!input) {
    input = 0;
  }
  sum += input;
} while (input > 0 && sum < 100);
document.write('<h1>' + sum + '</h1>');
